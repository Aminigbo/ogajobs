<section class="site-header">
    <a href="./">
        <img src="assets/images/icons/kedosic.svg" alt="" class="logo-img">
    </a>
    <ul class="site-sidebar">
        <li><a href="">home</a></li>
        <li><a href="">how it works</a></li>
        <li><a href="">who we are</a></li>
        <li><a href="">contact Us</a></li>
        <li><a href="">blog</a></li>
        <li><a href="" class="check-status-btn">check status</a></li>
    </ul>
    <button class="hamburger hide-on-desktop side-bar-btn"><i class="fa fa-bars"></i></button>
</section>